//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by scm2b2.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SCM2B2_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_1_LOC1                 1000
#define IDC_EDIT_2_LOC1                 1001
#define IDC_EDIT_1_STATE1               1002
#define IDC_EDIT_2_STATE1               1003
#define IDC_BUTTON_1_HOME1              1004
#define IDC_BUTTON_1_MINUS1             1005
#define IDC_BUTTON_1_1000G1             1006
#define IDC_BUTTON_1_PLUS1              1007
#define IDC_BUTTON_1_LIMIT1             1008
#define IDC_BUTTON_2_HOME1              1009
#define IDC_BUTTON_2_MINUS1             1010
#define IDC_BUTTON_2_1000G1             1011
#define IDC_BUTTON_2_PLUS1              1012
#define IDC_BUTTON_2_LIMIT1             1013
#define IDC_MOTORTYPE1                  1014
#define IDC_MOTORTYPE2                  1015
#define IDC_BRIGHTLIGHT1                1016
#define IDC_BRIGHTLIGHT2                1017
#define IDC_EDIT_1_LOC2                 1028
#define IDC_EDIT_2_LOC2                 1029
#define IDC_EDIT_1_STATE2               1030
#define IDC_EDIT_2_STATE2               1031
#define IDC_BUTTON_1_HOME2              1032
#define IDC_BUTTON_1_MINUS2             1033
#define IDC_BUTTON_1_1000G2             1034
#define IDC_BUTTON_1_PLUS2              1035
#define IDC_BUTTON_1_LIMIT2             1036
#define IDC_BUTTON_2_HOME2              1037
#define IDC_BUTTON_2_MINUS2             1038
#define IDC_BUTTON_2_100G2              1039
#define IDC_BUTTON_2_PLUS2              1040
#define IDC_BUTTON_2_LIMIT2             1041
#define IDC_Value1                      1042
#define IDC_BUTTON_OFF1                 1043
#define IDC_BUTTON_MINUS1               1044
#define IDC_BUTTON_MID1                 1045
#define IDC_BUTTON_PLUS1                1046
#define IDC_BUTTON_FULLON1              1047
#define IDC_Value2                      1048
#define IDC_BUTTON_OFF2                 1049
#define IDC_BUTTON_MINUS2               1050
#define IDC_BUTTON_MID2                 1051
#define IDC_BUTTON_PLUS2                1052
#define IDC_BUTTON_FULLON2              1053

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
